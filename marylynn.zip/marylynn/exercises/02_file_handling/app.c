#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#define MARKER_START "--8<--8<--8<--"
#define MARKER_END "-->8-->8-->8--"
#define MAX_TITLE 100


void sanitize_filename(char *filename) {

    const char* invalid_chars = "/\\:*?\"<>|";
    char *p = filename;

    while (*p) {
        const char *inv = invalid_chars; 
        while (*inv) {
            if (*p == *inv) {
                *p = ' '; 
                break;    
            }
            inv++;
        }
        p++; 
    }
}






// bool match_marker(FILE *fp, const char *marker) {
//     long pos = ftell(fp);
//     int i = 0;
//     int ch;
//     while (marker[i] != '\0') {
//         ch = fgetc(fp);
//         if (ch == EOF || ch != marker[i]) {
//             // reset if mismatch
//             fseek(fp, pos, SEEK_SET); 
//             return false;
//         }
//         i++;
//     }
//     return true;
// }

int main(void) {
    FILE *source_file = fopen("sample.txt", "r");

    if (source_file == NULL) return 1;

    FILE *extract_file = NULL;
    char title[MAX_TITLE] = "";
    char text[MAX_TITLE];
    bool insideMarkers = false;

    while (fgets(text, sizeof(text), source_file)) { //read line by line
         
        //line contains marker?
         if (strstr(text, MARKER_START) && strstr(text, MARKER_END)) { 

            //extract title between marker start and marker end
            //--8<--8<--8<--  Machine Serial Number -->8-->8-->8--

            char *start = strstr(text, MARKER_START) + strlen(MARKER_START);
            char *end = strstr(text, MARKER_END);

            size_t idx = end - start;
                if(idx >= sizeof(title)) idx = sizeof(title) - 1;
                strncpy(title, start, idx);
                
                title[idx] = '\0';

            sanitize_filename(title);

            // Create new file
            char filename[MAX_TITLE];
            snprintf(filename, sizeof(filename),"%s.txt", title);

            extract_file = fopen(filename, "w");
            if (extract_file == NULL) {
                fclose(source_file);
                return 1;
            }
            printf("New file: %s\n", filename);
            insideMarkers = true;
            continue;
        }

        // Write content if inside markers
        if (insideMarkers && extract_file) {
            fprintf(extract_file, "%s\n", text);
        }
    }

    fclose(source_file);
    return 0;
}