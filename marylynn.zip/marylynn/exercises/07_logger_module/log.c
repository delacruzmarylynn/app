#include "log.h"

int main() {
    LOG(LOG_LEVEL_DEBUG, "Client connected");
    LOG(LOG_LEVEL_INFO, "Successfully downloaded");
    LOG(LOG_LEVEL_ERROR, "Error: code=%d", -1);
    return 0;
}