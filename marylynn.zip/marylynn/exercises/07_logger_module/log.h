#ifndef __LOG_H__
#define __LOG_H__

#include <stdio.h>
#include <time.h>


typedef enum {
    LOG_LEVEL_DEBUG, 
    LOG_LEVEL_INFO,
    LOG_LEVEL_ERROR
} LogLevel;


static inline const char* log_level_to_string(LogLevel level) {
    switch (level) {
        case LOG_LEVEL_DEBUG:
            return "DEBUG";
        case LOG_LEVEL_INFO:  
            return "INFO";
        case LOG_LEVEL_ERROR: 
            return "ERROR";
        default:              
            return "UNKNOWN";
    }
}

//current time
static inline void current_time_string(char* buffer, size_t size) {
    time_t now = time(NULL);
    struct tm* t = localtime(&now);
    strftime(buffer, size, "%Y-%m-%d %H:%M:%S", t);
}

//LOG(LOG_LEVEL_ERROR, "Error: File not found");

#define LOG(level, x, ...)                                                 \
        char _time_buf[20];                                                \
        current_time_string(_time_buf, sizeof(_time_buf));                 \
        printf("[%s] [%s] " x " \n",                                       \
        _time_buf, log_level_to_string(level), ##__VA_ARGS__);             \
        fflush(stdout);                                                    \`

#endif 