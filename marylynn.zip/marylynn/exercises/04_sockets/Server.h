#ifndef __SERVER_H__
#define __SERVER_H__

#include <netinet/in.h> //for address
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <unistd.h>

#define PORT 8080
#define BUFFER_SIZE 65536

class Server {
  private:
    int server_fd;
    struct sockaddr_in address;
    socklen_t addrlen;

    static void *send_thread(void *arg);
    static int send_file(FILE *file, int socket_fd);

  public:
    Server();

    bool start_connection();
    void accept_client();

    ~Server();
};

#endif