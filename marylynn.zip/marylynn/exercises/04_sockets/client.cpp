#include "Client.h"
#include <cstring>

Client::Client() : client_fd(-1) {
    memset(&serv_addr, 0, sizeof(serv_addr));
}

bool Client::loadFilenames(int argc, const char *argv[]) {

    filename.clear();
    if (argc < 2) {
        std::cerr << "Error: No filenames provided.\n";
        return false;
    }

    for (int i = 1; i < argc; i++) {

        filename.push_back(argv[i]);
    }
    return !filename.empty();
}

// get
const std::vector<std::string> &Client::getFilename() const {
    return filename;
}

void Client::printFilenames() const {
    if (filename.empty()) {
        std::cout << "No files loaded.\n";
        return;
    }

    std::cout << "Ready to send " << filename.size() << " file(s):\n";
    for (const auto &fname : filename) {
        std::cout << " - " << fname << "\n";
    }
}

bool Client::connectToServer(const char *ip, int port) {
    int status;
    sleep(20);

    if (filename.empty()) {
        printf("Failed to connect. No filename is loaded.\n");
        return 1;
    }

    if ((client_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        printf("\n Socket creation error \n");
        return -1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    // Convert IPv4 and IPv6 addresses from text to binary
    // form
    if (inet_pton(AF_INET, ip, &serv_addr.sin_addr) <= 0) {
        printf(
            "\nInvalid address/ Address not supported \n");
        return -1;
    }

    if ((status = connect(client_fd, (struct sockaddr *)&serv_addr,
                          sizeof(serv_addr))) < 0) {
        printf("\nConnection Failed \n");
        return -1;
    }
    return true;
}

void Client::requestFiles() {
    char buffer[BUFFER_SIZE] = {0};
    ssize_t bytes_received;
    char output_filename[100];

    const auto &files = getFilename(); // get vector from getter

    printf("Requested files:\n");

    // Send filenames to server
    for (size_t i = 0; i < files.size(); i++) {
        std::string send_buffer = files[i] + "\n"; // append newline delimiter

        if (send(client_fd, send_buffer.c_str(), send_buffer.size(), 0) < 0) {
            perror("Send filename failed");
            close(client_fd);
            return; // no manual free needed
        }

        printf("[%zu]: %s\n", i + 1, files[i].c_str());
    }

    // Receive responses and files
    for (size_t i = 0; i < files.size(); i++) {
        memset(buffer, 0, BUFFER_SIZE);
        bytes_received = recv(client_fd, buffer, BUFFER_SIZE - 1, 0);

        if (bytes_received <= 0) {
            perror("Failed to receive buffer");
            close(client_fd);
            return;
        }

        if (strncmp(buffer, "SUCCESS", 7) != 0) {
            printf("Server buffer: %s\n", buffer);
            return; // keep connection open want multiple requests
        }

        printf("Server confirmed file exists. Receiving file...\n");

        snprintf(output_filename, sizeof(output_filename), "download_%s", files[i].c_str());

        if (receive_file(output_filename, client_fd) == 0) {
            printf("File '%s' received successfully.\n", output_filename);
        } else {
            printf("File reception failed.\n");
        }
    }
}

int Client::receive_file(const char *output_filename, int client_fd) {
    char buffer[BUFFER_SIZE];
    ssize_t bytes_received;
    uint64_t total_received = 0;
    uint64_t file_size; // delimiter file size

    // ig receive file size
    // int kay sa 32-bit 4 ra sya xxxxxxx kung long sa 64-bit kay 8 or 4 dependes system
    // size wont match kay what if 64-bit server to 32-ibt na client

    // header dapat fixed ang size
    // receive file size
    if (recv(client_fd, &file_size, sizeof(file_size), 0) != sizeof(file_size)) {
        printf("Error receiving file size");
        return 1;
    }

    printf("Receiving %s (%llu bytes)\n", output_filename, (unsigned long long)file_size);

    // Step 2: Open file for writing
    FILE *file = fopen(output_filename, "wb");
    if (!file) {
        printf("File open error");
        return -1;
    }

    unsigned char *p = (unsigned char *)&file_size;
    printf("Raw header bytes: ");
    for (int i = 0; i < 8; i++)
        printf("%02X ", p[i]);
    printf("\n");
    // Step 3: Receive file data
    while (total_received < file_size) {
        size_t to_read = (file_size - total_received > BUFFER_SIZE) ? BUFFER_SIZE : (file_size - total_received);
        bytes_received = recv(client_fd, buffer, to_read, 0);
        if (bytes_received <= 0) {
            printf("Receive error");
            fclose(file);
            return -1;
        }
        fwrite(buffer, 1, bytes_received, file);
        total_received += bytes_received;
    }

    fclose(file);
    return 0;
}

Client::~Client() {
    if (client_fd >= 0) {
        close(client_fd);
        printf("Connection closed. \n");
    }
}
