#ifndef __CLIENT_H__
#define __CLIENT_H__

#include <arpa/inet.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <sys/socket.h>
#include <unistd.h>
#include <vector>

#define PORT 8080
#define BUFFER_SIZE 65536

class Client {

  private:
    int client_fd;
    std::string ip;
    int port;
    struct sockaddr_in serv_addr;
    std::vector<std::string> filename;

    int receive_file(const char *output_filename, int client_fd);

  public:
    Client();

    bool loadFilenames(int argc, const char *argv[]);
    const std::vector<std::string> &getFilename() const;
    void printFilenames() const;

    bool connectToServer(const char *ip, int port = PORT);
    void requestFiles();

    ~Client();
};

#endif
