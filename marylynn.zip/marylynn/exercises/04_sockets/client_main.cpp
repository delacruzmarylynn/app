#include "Client.h"
#include "Server.h"
#include <iostream>

using namespace std;

int main(int argc, const char *argv[]) {
    Client client;

    // Load filenames
    if (!client.loadFilenames(argc, argv)) {
        return 1;
    }

    printf("Requested files:\n");
    for (const auto &fname : client.getFilename()) {
        // printf("- %s\n", fname.c_str()); read std::string
        cout << "-" << fname << "\n";
    }

    // Connect to the server
    if (client.connectToServer("127.0.0.1")) {
        client.printFilenames();
    }

    client.requestFiles();

    return 0;
}