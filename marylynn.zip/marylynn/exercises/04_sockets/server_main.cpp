#include "Server.h"
#include <iostream>

using namespace std;

int main() {
    Server server;

    if (!server.start_connection()) {
        std::cerr << "Failed to start server.\n";
        return 1;
    }

    server.accept_client();

    return 0;
}