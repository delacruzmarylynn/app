#include "Server.h"
#include <cstring>

Server::Server() : server_fd(-1), addrlen(sizeof(address)) {
    memset(&address, 0, sizeof(address));
}

bool Server::start_connection() {
    // Creating socket file descriptor
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    // Forcefully attaching socket to the port 8080
    if (bind(server_fd, (struct sockaddr *)&address,
             sizeof(address)) < 0) {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }

    if (listen(server_fd, 3) < 0) {
        perror("listen");
        exit(EXIT_FAILURE);
    }

    return true;
}

void Server::accept_client() {
    while (1) {

        int new_socket = accept(server_fd, (struct sockaddr *)&address, &addrlen);
        if (new_socket < 0) {
            perror("accept failed");
            continue;
        }

        printf("Client connected.\n");

        printf("%d\n", new_socket);

        sleep(10);

        int *client_socket = new int(new_socket); // allocate for thread
        pthread_t thread_id;

        if (pthread_create(&thread_id, NULL, Server::send_thread, client_socket) != 0) {
            perror("pthread_create failed");
            close(new_socket);
            continue;
        }

        pthread_detach(thread_id); // Auto-cleanup
        // sleep(5);

        // join will block until the thread finishes
        // prevents main from accepting new clients
        // clean thread resources automatically when it finishes
        // goal: handle multiple clients at once
        close(new_socket);
    }
}

void *Server::send_thread(void *arg) {
    int new_socket = *((int *)arg); // cast and dereference
    delete (int *)arg;
    char filename[100];
    ssize_t bytes_read;
    char recv_buffer[100]; // handle the newline delimiter from the client
    int filename_pos = 0;

    printf("\nWaiting for a new client...\n");
    printf("%d\n", new_socket);

    while (1) {

        // Receive one filename
        bytes_read = recv(new_socket, filename, sizeof(filename) - 1, 0);

        if (bytes_read <= 0) {
            if (bytes_read == 0) {
                printf("Client disconnected.\n");
            } else {
                printf("Socket: %d, bytes_read: %zd\n", new_socket, bytes_read);
                perror("recv filename failed\n");
            }
            break;
        }

        for (int i = 0; i < bytes_read; i++) {
            if (filename[i] == '\n') {
                filename[filename_pos] = '\0'; // End of filename
                printf("Client requested file: %s\n", filename);

                FILE *file = fopen(filename, "rb");
                if (!file) {
                    const char *error_msg = "ERROR: File not found";
                    send(new_socket, error_msg, strlen(error_msg), 0);
                    printf("File not found.\n");
                } else {
                    const char *success_msg = "SUCCESS: File is found";
                    send(new_socket, success_msg, strlen(success_msg), 0);

                    if (send_file(file, new_socket) == 0) {
                        printf("File sent successfully.\n");
                    } else {
                        printf("File sending failed.\n");
                    }
                    fclose(file);
                }

                // reset para next filename na pud
                filename_pos = 0;
            } else // what if ang current character kay dili newline
            {
                if (filename_pos < sizeof(filename) - 1) // naa pay space nabilin sa filename buffer?
                {
                    filename[filename_pos++] = filename[i];
                    // printf("Added char: '%c' Current filename: '%.*s'\n", filename[i], filename_pos, filename);
                }
            }
            sleep(2);
        }
    }

    close(new_socket);
    return NULL;
}

int Server::send_file(FILE *file, int new_socket) {

    char buffer[BUFFER_SIZE];
    size_t bytes_read;
    size_t total_sent;
    ssize_t bytes_sent;

    // get file size
    fseek(file, 0, SEEK_END);
    uint64_t file_size = ftell(file);
    fseek(file, 0, SEEK_SET);

    // Send file size first (8 bytes)
    if (send(new_socket, &file_size, sizeof(file_size), 0) != sizeof(file_size)) {
        perror("Error sending file size");
        return -1;
    }

    printf("Sending file of size: %llu bytes\n", (unsigned long long)file_size);

    // send file data
    while ((bytes_read = fread(buffer, 1, BUFFER_SIZE, file)) > 0) {
        total_sent = 0;

        while (total_sent < bytes_read) {

            bytes_sent = send(new_socket, buffer + total_sent, bytes_read - total_sent, 0);
            if (bytes_sent <= 0) {
                printf("ERROR SENDING");
                return -1; // Failure
            }
            total_sent += bytes_sent;
        }
    }
    if (ferror(file)) {
        perror("File read error");
        return -1;
    }

    return 0;
}

Server::~Server() {
    if (server_fd >= 0) {
        close(server_fd);
    }
}