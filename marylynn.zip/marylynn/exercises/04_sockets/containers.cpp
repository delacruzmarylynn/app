#include <iostream>
#include <list>
#include <map>
#include <string>
#include <vector>

using namespace std;
int main() {

    // --VECTOR--

    vector<string> files = {"A.exe", "B.exe", "C.exe"};

    cout << "Vector contents\n";

    for (size_t i = 0; i < files.size(); i++) {
        cout << files[i] << "\n";
    }

    // 'const auto&' avoids copying
    for (const auto &file : files) {
        cout << file << "\n";
    }

    // auto - deduce the type of file automatically from the container (string)
    //&(reference) - avoids making a copy of each element. File will refer directly to the element inside the vector
    // const - prevents modify of the element. read-only access

    // auto file - copies each element into fruit
    // auto &file - references the element directly, without copy, but allows modification
    // const auto &file - references the element directly, without copy, but prevents modification

    for (vector<string>::iterator itr = files.begin(); itr != files.end(); ++itr) {
        cout << *itr << "\n";
    }

    for (vector<string>::iterator itr = files.begin(); itr != files.end(); ++itr) {
        *itr += " (Apps)";
    }

    for (auto itr = files.begin(); itr != files.end(); ++itr) {
        cout << *itr << "\n";
    }

    vector<int> numbers;

    // Push elements into vector
    for (int i = 1; i <= 10; ++i) {
        numbers.push_back(i);
    }

    for (int i = 0; i < numbers.size(); i++) {
        cout << numbers[i] << " ";
    }
    cout << "\n";

    // --LIST--

    cout << "\nList contents\n";

    list<int> numbers_list = {1, 2, 3, 4, 5};

    list<int>::iterator itr = numbers_list.begin();
    while (itr != numbers_list.end()) {
        cout << *itr << " ";
        ++itr;
    }
    cout << "\n";

    list<string> files_list;

    files_list.push_front("A");
    files_list.push_back("B");

    for (list<string>::iterator itr = files_list.begin(); itr != files_list.end(); ++itr) {
        cout << *itr << " ";
    }
    cout << "\n";

    // --MAP--

    map<string, int> name_map;

    // Insert using pair
    name_map.insert(pair<string, int>("A", 65));

    // Insert using operator[]
    name_map["B"] = 66;
    name_map["C"] = 67;

    cout << "\nMap contents (key -> value):\n";
    map<string, int>::iterator map_itr = name_map.begin();
    while (map_itr != name_map.end()) {
        cout << map_itr->first << " -> " << map_itr->second << "\n";
        ++map_itr;
    }

    return 0;
}
