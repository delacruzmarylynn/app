#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#define PORT 8080
#define BUFFER_SIZE 65536

// Helper to ensure we read exactly 'len' bytes
ssize_t recv_all(int sock, void *buf, size_t len) {
    size_t total = 0;
    ssize_t n;
    while (total < len) {
        n = recv(sock, (char *)buf + total, len - total, 0);
        if (n <= 0)
            return n; // error or connection closed
        total += n;
    }
    return total;
}
int receive_file(const char *output_filename, int client_fd) {
    char buffer[BUFFER_SIZE];
    ssize_t bytes_received;
    uint64_t total_received = 0;
    uint64_t file_size; // delimiter file size

    // ig receive file size
    // int kay sa 32-bit 4 ra sya xxxxxxx kung long sa 64-bit kay 8 or 4 dependes system
    // size wont match kay what if 64-bit server to 32-ibt na client

    // header dapat fixed ang size

    // receive file size
    if (recv_all(client_fd, &file_size, sizeof(file_size)) != sizeof(file_size)) {
        printf("Error receiving file size");
    }

    printf("Receiving %s (%llu bytes)\n", output_filename, (unsigned long long)file_size);

    // Step 2: Open file for writing
    FILE *fp = fopen(output_filename, "wb");
    if (!fp) {
        perror("File open error");
        return -1;
    }

    // Step 3: Receive file data
    while (total_received < file_size) {
        size_t to_read = (file_size - total_received > BUFFER_SIZE) ? BUFFER_SIZE : (file_size - total_received);
        bytes_received = recv(client_fd, buffer, to_read, 0);
        if (bytes_received <= 0) {
            perror("Receive error");
            fclose(fp);
            return -1;
        }
        fwrite(buffer, 1, bytes_received, fp);
        total_received += bytes_received;
    }

    fclose(fp);
    printf("File %s received successfully.\n", output_filename);
}

int main(int argc, char const *argv[]) {
    int status, valread, client_fd;
    struct sockaddr_in serv_addr;
    const char *hello = "Hello from client";
    char buffer[BUFFER_SIZE] = {0};
    ssize_t bytes_received;
    long file_size, total_received = 0;
    FILE *file;
    char output_filename[100];

    if (argc < 2) {
        printf("Invalid input. Add file to request.");
        return 1;
    }

    // Allocate an array of char* to store copies
    char **filename = malloc((argc - 1) * sizeof(char *));
    if (filename == NULL) {
        printf("Memory allocation failed");
        return 1;
    }

    // Copy each argument dynamically
    for (int i = 1; i < argc; i++) {
        filename[i - 1] = malloc(strlen(argv[i]) + 1); // +1 for null terminator
        if (filename[i - 1] == NULL) {
            printf("Memory allocation failed");
            // Free already allocated memory before exiting
            for (int j = 0; j < i - 1; j++) {
                free(filename[j]);
            }
            free(filename[i]);
            return 1;
        }
        strcpy(filename[i - 1], argv[i]); // Safe coz exact size is allocated
    }

    if ((client_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        printf("\n Socket creation error \n");
        return -1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    // Convert IPv4 and IPv6 addresses from text to binary
    // form
    if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {
        printf(
            "\nInvalid address/ Address not supported \n");
        return -1;
    }

    if ((status = connect(client_fd, (struct sockaddr *)&serv_addr,
                          sizeof(serv_addr))) < 0) {
        printf("\nConnection Failed \n");
        return -1;
    }

    printf("Requested files:\n");
    for (int i = 0; i < argc - 1; i++) {
        char send_buffer[100];

        snprintf(send_buffer, sizeof(send_buffer), "%s\n", filename[i]); // append newline delimiter every after filename

        if (send(client_fd, send_buffer, strlen(send_buffer), 0) < 0) {
            printf("Send filename failed");
            close(client_fd);
            for (int j = 0; j < argc - 1; j++) {
                free(filename[j]);
            }
            free(filename);
            return 1;
        }
        printf("[%d]: %s\n", i + 1, filename[i]);
        // sleep(1);
    }

    // sleep(1);

    for (int i = 0; i < argc - 1; i++) {
        // Receive server buffer
        memset(buffer, 0, BUFFER_SIZE);
        bytes_received = recv(client_fd, buffer, BUFFER_SIZE - 1, 0);
        printf("Bytes received: %zd\n", bytes_received);
        if (bytes_received <= 0) {
            printf("Failed to receive buffer.");
            close(client_fd);
            return 1;
        }

        // printf("Buffer: %s\n", buffer);

        // Check if server sent SUCCESS

        if (strncmp(buffer, "SUCCESS", 7) != 0) {
            printf("Server buffer: %s\n", buffer);
            // close(client_fd); Request man more files sa isa ka session
            return 0;
        }
        //  printf("Server response: %s\n", buffer);
        printf("Server confirmed file exists. Receiving file...\n");
        // sleep(5);
        // whyzz stuckedtttzzzzz? filenames:naconcatenatenames = file: [image.jpg][maze.bmp][dot.png] .... -> character na pud? naurrrr...naguba ang pic. header file size???
        // Receive the rest of the file

        snprintf(output_filename, sizeof(output_filename), "download_%s", filename[i]);

        if (receive_file(output_filename, client_fd) == 0) {
            printf("File '%s' received successfully.\n", output_filename);
        } else {
            printf("File reception failed.\n");
        }
    }

    printf("Successfully downloaded.\n");

    fclose(file);

    close(client_fd);
    return 0;
}