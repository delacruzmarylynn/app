#include <stdio.h>
#include <stdlib.h>

/*
    char input[100] = "Kyocera";

    replaceAllChar(input, 'e', '3');
    // input should become Kyoc3ra.

    replaceAllChar(input, 'o', '0');
    // input should become Ky0c3ra
*/
void replaceAllChar(char* input, char find_char, char replace_char) {
while (*input){
    if (*input == find_char){       
       *input = replace_char;
    }
    input++;
}
}

/*
    char input[100] = "Kyocera Document Solutions Development Inc.";

    int index = findIndexOfStr(input, "Doc");
    // index should be 8.

    index = findIndexOfStr(input, "era");
    // index should be 4.
*/

int findIndexOfStr(const char *input, const char *find_str) {

    //input[??]
    //findstr[??]

    if (*find_str == '\0' || *input == '\0') return -1; 

    int i = 0;
    while (input[i] != '\0') {
        int j = 0;
        while (find_str[j] != '\0' && input[i + j] != '\0' &&
               input[i + j] == find_str[j]) {
            j++;
        }
        if (find_str[j] == '\0') {
            return i; 
        }
        i++;
    }
    return -1; 
}

// Other Method:
// int startsWith(char* input, char* find_str){
//     while(*input) {
//         while(*find_str && *input){
//             if(*find_str != *input){
//                 return 0;
//             }
//             find_str++;
//             input++;
//         }
//         if (*find_str == NULL) {
//             return 1;
//         }
//     }
// }

// int findIndexOfStr(char* input, char* find_str)
// {
//     int index = -1;

//     if(*input == NULL || *find_str == NULL) return -1;

//         while(*input){
//             if(startsWith(input,find_str)){
//              return index + 1;
//         }
//         input++;
//     }
//     return index;
// }

int main(void) {
    char input[100] = "Kyocera Document Solutions";
    char find_str[100] = "era";

    int index = findIndexOfStr(input, find_str);
    replaceAllChar(input, 'e', '3');

    printf("Modified Input: %s\n", input);
    

    if(index != -1)
    printf("%s is found in %d\n", find_str, index);
    else
    printf("%s not found. Found in %d\n", find_str, index);
    return 0;
}

