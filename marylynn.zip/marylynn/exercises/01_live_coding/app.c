#include <stdio.h>
#include <stdlib.h>

void copyString(char* dest, const char* src) {
   
   while ((*dest++ = *src++) != '\0')
   ;
}

bool areStringsEqual(char* str1, char* str2) {

    int i=0; int isEqual = 1;
    while(str1[i] != '\0' || str2[i] != '\0'){
    if(str1[i] != str2[i]){
        return false;
        break;
    }
    i++;
    }

    return true;

}

/**
 *  Print the input string str as hex.
 *  e.g. input str = "Kyocera"
 *
 *  4b 79 6f 63 65 72 61
 *
 */


void deci_to_hexa(int decimal_number) {
    char hexa_number[3]; 
    int i = 0;

    if (decimal_number == 0) {
        printf("00");
        return;
    }

    while (decimal_number != 0 && i < 2) {
        int temp = decimal_number % 16;
        if (temp < 10)
            hexa_number[i] = temp + '0';
        else
            hexa_number[i] = temp - 10 + 'a';
        decimal_number /= 16;
        i++;
    }

    if (i == 1) {
        hexa_number[i] = '0';
        i++;
    }

    for (int j = i - 1; j >= 0; j--) {
        printf("%c", hexa_number[j]);
    }
}

void printAsHex(const char *str) {
    //string to (ascii) deci -> hex

    while (*str) {
        int ascii_val = (unsigned char)*str; 
        deci_to_hexa(ascii_val);   
        printf(" "); 
        str++;
    }
    
}


int main(void) {
    char my_str[100] = {0};
   
    //name[0] = '\0';
    copyString(my_str, "Kyocera");
    printf("my_str: %s\n", my_str);
    
    if (areStringsEqual(my_str, (char*) "Kyocera")) {
        printf("Strings are equal\n");
    
        printAsHex(my_str); // This should output: 4b 79 6f 63 65 72 61
    }
    else {
        printf("Strings are not equal\n");
    }

    return 0;
}
